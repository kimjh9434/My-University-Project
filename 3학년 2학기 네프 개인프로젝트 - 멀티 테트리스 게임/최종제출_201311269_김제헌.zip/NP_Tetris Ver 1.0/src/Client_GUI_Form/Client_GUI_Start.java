package Client_GUI_Form;

public class Client_GUI_Start {
	static public void main(String args[]){
		GUI_MainJFrame main = new GUI_MainJFrame();
	}
}
