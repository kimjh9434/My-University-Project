package Magic;

import UnitList.Unit;

public interface DefensiveMatrix {
	public void defensiveMatrix(Unit u);
}
