package Magic;

public interface SiegeMode {
	public void siegeMode();
}
