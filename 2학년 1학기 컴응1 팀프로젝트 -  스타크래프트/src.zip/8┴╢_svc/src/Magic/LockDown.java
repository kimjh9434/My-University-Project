package Magic;

import UnitList.Unit;

public interface LockDown {
	public void lockdown(Unit u);
}
