package Magic;

public interface Steampack {
	public void steampack(int turn);
	public void steamover();
}
