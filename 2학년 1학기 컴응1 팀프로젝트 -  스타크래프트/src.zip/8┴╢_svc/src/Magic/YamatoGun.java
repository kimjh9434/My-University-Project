package Magic;
import UnitList.Unit;
public interface YamatoGun {
	public void yamatoGun(Unit u);
}
