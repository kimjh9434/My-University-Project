#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <Windows.h>
#include "getinfo.h"
#define MAX_SIZE 100
#define MAX_INPUT_SIZE 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1

int leng;
int rleng;   
/*result 배열의 총 크기*/

/*터미널 정보로 정렬*/
int compare1(const void *c1, const void *c2){      
   struct termInfo *p1 = (struct termInfo*)c1;
   struct termInfo *p2 = (struct termInfo*)c2;
   
   return strcmp(p1->terminalinfo,p2->terminalinfo);
}

/*반올림*/
int rounder(double number)
{
    return (number >= 0) ? (int)(number + 0.5) : (int)(number - 0.5);
}


void swap(struct termInfo* t1, struct termInfo* t2){
   struct termInfo temp;

   temp = *t1;
   *t1 = *t2;
   *t2 = temp;
}

void sortBal(struct termInfo* temp){
   int ti;
   int tj=0;
   int tk;
   char* tc1;      /*분*/
   char* tc2;      /*초*/
   char tempc[20];
   int sec1;
   int sec2;
   int size=1;      /*같은 터미널 정보의 개수*/

   for(tk = 0; tk<leng-1; tk++){
      
      if((strcmp(temp[tk].terminalinfo,temp[tk+1].terminalinfo) == 0)){
         /*터미널정보가 같은경우에 size 늘려준다.*/
         size++;
         /*printf("==SAME\n첫번째:%s 두번째:%s\n",temp[tk].terminalinfo,temp[tk+1].terminalinfo);*/
         
         if(tk == leng-2){
            /*마지막 터미널에서도 버블정렬*/
            for(ti=tk-size+1; ti<=tk+1; ti++){
               for(tj=tk-size+1;tj<=tk; tj++){
                  strcpy(tempc,temp[ti].lastTagTime);
                  tc1=strtok(tempc,":");
                  tc2=strtok(NULL,":");
                  /*앞에있는거 초*/
                  sec1 = atoi(tc1)*60 + atoi(tc2);   
         
                  strcpy(tempc,temp[tj].lastTagTime);
                  tc1=strtok(tempc,":");
                  tc2=strtok(NULL,":");
                  /*뒤에있는거 초*/
                  sec2 = atoi(tc1)*60 + atoi(tc2);   
         
         
                  if(sec2 > sec1){
                     swap(&temp[ti],&temp[tj]);
                  }
               }
            }
         }
      }
      
      else{
         /*앞뒤의 터미널 정보가 다르면
         터미널 정보 같은 애들끼리 버블정렬
         맨뒤가 하나일 경우, 터미널정보를 이미 끝낸상태이므로 내버려둔다.*/
         printf("!!!DIF\n첫번째:%s 두번째:%s\n",temp[tk].terminalinfo,temp[tk+1].terminalinfo);
         for(ti=tk-size+1; ti<=tk; ti++){
            for(tj=tk-size+1;tj<=tk-1; tj++){
               strcpy(tempc,temp[ti].lastTagTime);
               tc1=strtok(tempc,":");
               tc2=strtok(NULL,":");
               /*앞에있는거 초*/
               sec1 = atoi(tc1)*60 + atoi(tc2);   
         
               strcpy(tempc,temp[tj].lastTagTime);
               tc1=strtok(tempc,":");
               tc2=strtok(NULL,":");
               /*뒤에있는거 초*/
               sec2 = atoi(tc1)*60 + atoi(tc2);   
         
         
               if(sec2 > sec1){
                  swap(&temp[ti],&temp[tj]);
               }
            }
         }

         size = 1;
      }
   }
}



/*두 파일에서 정보 받아다 저장*/
void getInfo(struct result* rr){
   struct termInfo infos[MAX_SIZE];
   char termInput[MAX_INPUT_SIZE];
   int j;
   char tempchar[MAX_INPUT_SIZE];
   char endFile[4];
   char* line_p;
   int ti;
   int tj=0;
   int tk;
   char tempc[20];
   int sec1;
   int sec2;
   int size=0;      /*같은 터미널 정보의 개수*/

   FILE *f;
   leng=0;
   /*지하철에서*/
   f =   fopen("metro.txt","r");

   if(f == NULL) perror("지하철파일 위치를 확인\n");
   /*지하철 정보들을 받아다 입력*/
   else {
      while(fgets(termInput,MAX_INPUT_SIZE,f)!=NULL){         /*파일 끝날때까지*/
         if(leng>=MAX_SIZE){
            printf("FULL\n");
         }
         else{
            strcpy(tempchar,strtok(termInput," "));      /*태그시간   */
            strcpy(infos[leng].lastTagTime,tempchar);
            
            strcpy(tempchar,strtok(NULL," "));         /*교통수단*/
            if(strcmp(tempchar,"BUS") == 0){
               infos[leng].transportation = BUS;
            }
            else if(strcmp(tempchar,"METRO") == 0){
               infos[leng].transportation = METRO;
            }
            else{
               printf("BUS나 METRO가 아닙니다\n");
            }

            strcpy(tempchar,strtok(NULL," "));               /*승하차*/
            if(strcmp(tempchar,"BOARD") == 0){
               infos[leng].in_out = BOARD;
            }
            else if(strcmp(tempchar,"LEFT") == 0){
               infos[leng].in_out = LEFT;
            }
            else
               printf("BOARD LEFT 이 아닙니다\n");

            strcpy(tempchar,strtok(NULL," "));               /*요금*/
            infos[leng].balance = atoi(tempchar);

            strcpy(tempchar,strtok(NULL," "));               /*터미널*/
            if((line_p = strchr(tempchar, '\n')) != NULL)*line_p ='\0';
            strcpy(infos[leng].terminalinfo,tempchar);

            leng++;
         }
      }
      fclose(f);
   }


   /*버스에서*/
   f =   fopen("bus.txt","r");
   if(f == NULL) perror("버스파일 위치를 확인\n");
   /*지하철 정보들을 받아다 입력*/
   else {
      while(fgets(termInput,MAX_INPUT_SIZE,f)!=NULL){         /*파일 끝날때까지*/
         if(leng>=MAX_SIZE)
            printf("터미널정보 최대치\n");
         else{
            strcpy(tempchar,strtok(termInput," "));         /*태그시간   */
            strcpy(infos[leng].lastTagTime,tempchar);

            strcpy(tempchar,strtok(NULL," "));            /*교통수단*/
            if(strcmp(tempchar,"BUS") == 0){
               infos[leng].transportation = BUS;
            }
            else if(strcmp(tempchar,"METRO") == 0){
               infos[leng].transportation = METRO;
            }
            else{
               printf("BUS나 METRO가 아닙니다\n");
            }

            strcpy(tempchar,strtok(NULL," "));               //승하차
            if(strcmp(tempchar,"BOARD") == 0){
               infos[leng].in_out = BOARD;
            }
            else if(strcmp(tempchar,"LEFT") == 0){
               infos[leng].in_out = LEFT;
            }
            else
               printf("BOARD LEFT 이 아닙니다\n");

            strcpy(tempchar,strtok(NULL," "));               //요금
            infos[leng].balance = atoi(tempchar);

            strcpy(tempchar,strtok(NULL," "));               //터미널
            if((line_p = strchr(tempchar, '\n')) != NULL)*line_p ='\0';
            strcpy(infos[leng].terminalinfo,tempchar);
            
            leng++;
         }
      }
      fclose(f);
   }
   
   qsort(infos,leng,sizeof(struct termInfo),compare1);

   sortBal(infos);
   
   /*printf("\n\n시간정렬 후 \n");
   for(j=0; j<leng ; j++){
      printf("\n%d번쨰 : lt = %s\n",j,infos[j].lastTagTime);
      printf("%d번쨰 : tr = %d\n",j,infos[j].transportation);
      printf("%d번쨰 : io = %d\n",j,infos[j].in_out);
      printf("%d번쨰 : bal = %d\n",j,infos[j].balance);
      printf("%d번쨰 : ti = %s\n",j,infos[j].terminalinfo);
   }
   printf("leng : %d\n",leng);*/
   
   rleng = 0;

   for(tk = 0; tk<leng-1; tk++){      
      /*printf("TK:%d\n",tk);*/
      if((strcmp(infos[tk].terminalinfo,infos[tk+1].terminalinfo) == 0)){
         /*터미널정보가 같은경우에 size 늘려준다.*/
         size++;
         /*printf("SAME\n");*/
         /*마지막에 여러개인경우*/
         if(tk == leng-2){
            /*마지막이 짝수개인경우*/
            /*printf("final SIZE %d",size);*/
            if(size%2 ==1){
               for(ti=tk-size+1; ti<=tk+1; ti +=2){
                  /*printf("TI:%d  TK:%d\n",ti,tk);*/
                  /*홀수번째 원소이면 다 저장해준다.*/
                  rr[rleng].fee = infos[ti].balance;
                  rr[rleng].transportation = infos[ti].transportation;
                  strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
                  strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
                  /*짝수번째는 금액만 저장해준다*/
                  rr[rleng].fee += infos[ti+1].balance;
                  rleng++;
               }
            }
            /*마지막이 홀수개인경우*/
            else{
               for(ti=tk-size+1; ti<=tk-1; ti +=2){
                  /*printf("TI:%d  TK:%d\n",ti,tk);*/
                  /*홀수번째 원소이면 다 저장해준다.*/
                  rr[rleng].fee = infos[ti].balance;
                  rr[rleng].transportation = infos[ti].transportation;
                  strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
                  strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
                  /*짝수번째는 금액만 저장해준다*/
                  rr[rleng].fee += infos[ti+1].balance;
                  rleng++;
               }
               rr[rleng].fee = infos[tk+1].balance;
               rr[rleng].transportation = infos[tk+1].transportation;
               strcpy(rr[rleng].lastTagTime,infos[tk+1].lastTagTime);
               strcpy(rr[rleng].terminalinfo,infos[tk+1].terminalinfo);
               rleng++;
            }
         }
      }
      else{
         /*앞뒤의 터미널 정보가 다르면
         같은 놈들끼리 새 구조체에 만들어준다
         마지막에 비교해서 다르면, 마지막것도 저장해준다.*/
         /*printf("DIFF\n");*/
         if(tk == leng-2){
            rr[rleng].fee = infos[tk+1].balance;
            rr[rleng].transportation = infos[tk+1].transportation;
            strcpy(rr[rleng].lastTagTime,infos[tk+1].lastTagTime);
            strcpy(rr[rleng].terminalinfo,infos[tk+1].terminalinfo);
            rleng++;
         }
         
         /*하나인경우*/
         if(size ==0){
            rr[rleng].fee = infos[tk].balance;
            rr[rleng].transportation = infos[tk].transportation;
            strcpy(rr[rleng].lastTagTime,infos[tk].lastTagTime);
            strcpy(rr[rleng].terminalinfo,infos[tk].terminalinfo);
            rleng++;
         }

         else{
            for(ti=tk-size; ti<=tk; ti++){
               /*승차하고 하차한 경우 둘을 더해준다*/
               if(infos[ti].in_out==BOARD && infos[ti+1].in_out==LEFT){
                  rr[rleng].fee = infos[ti].balance;
                  rr[rleng].transportation = infos[ti].transportation;
                  strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
                  strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
                  rr[rleng].fee += infos[ti+1].balance;   //하차금액 더한다
                  rleng++;
                  ti++;   //앞에 하차한 값은 넘김
               }

               else if(infos[ti].in_out==BOARD && infos[ti+1].in_out==BOARD){
                  rr[rleng].fee = infos[ti].balance;
                  rr[rleng].transportation = infos[ti].transportation;
                  strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
                  strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
                  rleng++;
               }

               //if(ti==leng-2){
               //   rr[rleng].fee = infos[ti].balance;
               //   rr[rleng].transportation = infos[ti].transportation;
               //   strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
               //   strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
               //   rleng++;
               //}
               //else{
               //   rr[rleng].fee = infos[ti].balance;
               //   rr[rleng].transportation = infos[ti].transportation;
               //   strcpy(rr[rleng].lastTagTime,infos[ti].lastTagTime);
               //   strcpy(rr[rleng].terminalinfo,infos[ti].terminalinfo);
               //   /*짝수번째는 금액만 저장해준다*/
               //   if(strcmp(infos[ti].terminalinfo,infos[ti+1].terminalinfo)){
               //   rr[rleng].fee += infos[ti+1].balance;
               //   rleng++;
               //   }
               //}
            }
         
         }
         size = 0;
      }
   }

   /*for(j=0; j<rleng ; j++){
      printf("\n%d번쨰 : lt = %s\n",j,rr[j].lastTagTime);
      printf("%d번쨰 : tr = %d\n",j,rr[j].transportation);
      printf("%d번쨰 : fee = %d\n",j,rr[j].fee);
      printf("%d번쨰 : terminal = %s\n",j,rr[j].terminalinfo);
   }*/
}

void adjustment(struct result* rt){
   int size=0;
   int ai;
   int aj;
   int ri;
   int rj=0;
   int total=0;
   int temp=0;
   int fee=0;
   int j;

   for(ai = 0; ai<rleng-1; ai++){
      if((strcmp(rt[ai].terminalinfo,rt[ai+1].terminalinfo) == 0)){
         /*터미널정보가 같은경우에 size 늘려준다.*/
         size++;
         printf("SAME\n");
         /*마지막일때 따로 정산*/
         if(ai == rleng-2){
            printf("SIZE:%d  ai:%d\n",size,ai);
            for(ri=ai-size+1; ri<=ai+1;ri++){
               for(rj=ai+1;rj>=ri;rj--){
                  total += rt[rj].fee;
               }
               fee += rt[ri].fee;
            }
            printf("total:%d\n",total);
            for(ri=ai-size+1; ri<=ai+1;ri++){
               for(rj=ai+1;rj>=ri;rj--){
                  temp += rt[rj].fee;
               }
               
               printf("fee:%d\n",fee);
               printf("temp:%d\n",temp);
               rt[ri].fee= rounder(((double)temp/(double)total)*(double)fee);
               temp=0;
            }
         }
      }

      /*터미널 정보가 다른경우, 해당범위까지 정산*/
      
      else{
         printf("DIFF\n");
         if(size==0){
            printf("one\n"); /*정산시 한개짜리는 그냥 둔다*/
         }
         else {
            printf("SIZE:%d  ai:%d\n",size,ai);
            for(ri=ai-size; ri<=ai;ri++){
               for(rj=ai;rj>=ri;rj--){
                  total += rt[rj].fee;
               }
               fee += rt[ri].fee;
               printf("total:%d\n",total);
               printf("fee:%d\n",fee);
            }
            
            for(ri=ai-size; ri<=ai;ri++){
               for(rj=ri;rj<=ai;rj++){
                  temp += rt[rj].fee;
               }
               rt[ri].fee= rounder(((double)temp/(double)total)*(double)fee);
               temp = 0;
            }
         }
         total=0;
         size=0;
         fee=0;
      }
   }

   for(j=0; j<rleng ; j++){
      printf("\n%d번쨰 : lt = %s\n",j,rt[j].lastTagTime);
      printf("%d번쨰 : tr = %d\n",j,rt[j].transportation);
      printf("%d번쨰 : fee = %d\n",j,rt[j].fee);
      printf("%d번쨰 : fee = %s\n",j,rt[j].terminalinfo);
   }
}

void fileSave(struct result* ff){
   int i;
   FILE *f;
   char feeb[5];      /*정산금액 char 할당*/


   for(i=0; i<rleng; i++){
      /*버스이면*/
      if(ff[i].transportation == 0){
         f = fopen("busCompany.txt","a+");
         fputs(ff[i].lastTagTime,f);
         fputs(",",f);
         fputs("BUS",f);
         fputs(",",f);

         sprintf(feeb,"%d",ff[i].fee);
         fputs(feeb,f);
         fputs("\n",f);
         fclose(f);
      }
      /*지하철이면*/
      else{
         f = fopen("metroCompany.txt","a+");
         fputs(ff[i].lastTagTime,f);
         fputs(",",f);
         fputs("METRO",f);
         fputs(",",f);

         sprintf(feeb,"%d",ff[i].fee);
         fputs(feeb,f);
         fputs("\n",f);
         fclose(f);
      }
   }
}

int main(){
   struct result t[MAX_SIZE];
   int i;
   time_t timer;
   struct tm *tim;
   int min=0;
   int sec=0;


   while(1){
      timer = time(NULL);
      tim = localtime(&timer);
   
      printf("%02d:%02d\n", min, sec);
      min = tim->tm_min%3;
      sec = tim->tm_sec;
      Sleep(300);
      if (min*60 + sec == 179){
         
         printf("정산한다\n");
         getInfo(t);
         adjustment(t);
         fileSave(t);
         Sleep(5000);
      }
   }
}
