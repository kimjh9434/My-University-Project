#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
struct termInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
};

struct result{
	char lastTagTime[20];
	int transportation;
	int fee;
	char terminalinfo[6];
};
int leng;
int compare1(const void *c1, const void *c2);
void getInfo(struct result* rr);
//struct result* sorting(struct termInfo* temp);
void sortBal(struct termInfo* temp);
void adjustment(struct result* rt);
int rounder(double number);
