#include "subway_out.h"
#include "subway.h"


extern char c;			//마지막 요금 판단을 위해서 전역변수 사용!
extern int terminalCount[6];
extern int check;
extern char username[20];
extern struct userInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}userinfo;
extern struct currentInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}currentinfo;


int check_out()		// 하차에서 어떤 요금을 부과할지 결정!
{
	check = 0;
	if (userinfo.in_out == BOARD && userinfo.transportation == METRO && currentinfo.in_out == LEFT && currentinfo.transportation == METRO)
	{
		if (userinfo.terminalinfo[0] != 'a' && currentinfo.terminalinfo[0] != 'a')
		{
			currentinfo.balance = nottrans_cal(); // 0원, 200원 둘 중 하나 부과 --> 0,1 정거장 ==0원, 2정거장 = 200원 / 지하철 승차 후 지하철 하차 한 경우, 앞에 환승 기록 없음
			userinfo.balance = userinfo.balance - currentinfo.balance;
			userinfo.in_out = currentinfo.in_out;
			strcpy(userinfo.lastTagTime, currentinfo.lastTagTime);
			strcpy(currentinfo.terminalinfo, userinfo.terminalinfo);
			userinfo.transportation = currentinfo.transportation;


		}
		else if (userinfo.terminalinfo[0] == 'a' && currentinfo.terminalinfo[0] != 'a')
		{
			currentinfo.balance = trans_cal();	// 300원, 600원 둘 중 하나 부과! --> 1정거장 = 300원, 2정거장 = 600원 / 버스에서 지하철 환승 후)
			userinfo.balance = userinfo.balance - currentinfo.balance;
			userinfo.in_out = currentinfo.in_out;
			strcpy(userinfo.lastTagTime, currentinfo.lastTagTime);
			strcpy(currentinfo.terminalinfo, userinfo.terminalinfo);
			userinfo.transportation = currentinfo.transportation;



		}
	}

	/*else if (userinfo.in_out == 1 && currentinfo.in_out == 1)  // 나올 수 없음! ==> 하차 후 하차는 예외처리 해야함!!
	{
	}*/

	return 0;
}


int nottrans_cal() {		// 미환승(전에 탄게 지하철)요금 계산
	int station0 = 0;		// 0 정거장 이동
	int station1 = 0;		// 한 정거장 이동
	int station2 = 200;		// 두 정거장 이동

	if ((userinfo.terminalinfo[0] == 'b' && currentinfo.terminalinfo[0] == 'b')
		|| (userinfo.terminalinfo[0] == 'c' && currentinfo.terminalinfo[0] == 'c')
		|| (userinfo.terminalinfo[0] == 'd' && currentinfo.terminalinfo[0] == 'd')
		|| (userinfo.terminalinfo[0] == 'e' && currentinfo.terminalinfo[0] == 'e')
		|| (userinfo.terminalinfo[0] == 'f' && currentinfo.terminalinfo[0] == 'f'))
	{
		printf("하차시 추가요금 : %d원\n", station0);

		return station0;
	}
	else if ((userinfo.terminalinfo[0] == 'b' && (currentinfo.terminalinfo[0] == 'f' || currentinfo.terminalinfo[0] == 'c'))
		|| (userinfo.terminalinfo[0] == 'c' && (currentinfo.terminalinfo[0] == 'b' || currentinfo.terminalinfo[0] == 'd'))
		|| (userinfo.terminalinfo[0] == 'd' && (currentinfo.terminalinfo[0] == 'c' || currentinfo.terminalinfo[0] == 'e'))
		|| (userinfo.terminalinfo[0] == 'e' && (currentinfo.terminalinfo[0] == 'd' || currentinfo.terminalinfo[0] == 'f'))
		|| (userinfo.terminalinfo[0] == 'f' && (currentinfo.terminalinfo[0] == 'e' || currentinfo.terminalinfo[0] == 'b')))
	{
		printf("하차시 추가요금 : %d원\n", station1);
		return station1;
	}
	else if ((userinfo.terminalinfo[0] == 'b' && (currentinfo.terminalinfo[0] == 'd' || currentinfo.terminalinfo[0] == 'e'))
		|| (userinfo.terminalinfo[0] == 'c' && (currentinfo.terminalinfo[0] == 'e' || currentinfo.terminalinfo[0] == 'f'))
		|| (userinfo.terminalinfo[0] == 'd' && (currentinfo.terminalinfo[0] == 'f' || currentinfo.terminalinfo[0] == 'b'))
		|| (userinfo.terminalinfo[0] == 'e' && (currentinfo.terminalinfo[0] == 'b' || currentinfo.terminalinfo[0] == 'c'))
		|| (userinfo.terminalinfo[0] == 'f' && (currentinfo.terminalinfo[0] == 'c' || currentinfo.terminalinfo[0] == 'd')))
	{
		printf("하차시 추가요금 : %d원\n", station2);

		return station2;
	}


}
int trans_cal() {			// 환승(전에 탄게 버스)요금 계산
	int station0 = 0;		// 0 정거장 이동 
	int station1 = 300;		// 한 정거장 이동 
	int station2 = 600;		// 두 정거장 이동
	if
		((c == 'b' && currentinfo.terminalinfo[0] == 'b')
		|| (c == 'c' && currentinfo.terminalinfo[0] == 'c')
		|| (c == 'd' && currentinfo.terminalinfo[0] == 'd')
		|| (c == 'e' && currentinfo.terminalinfo[0] == 'e')
		|| (c == 'f' && currentinfo.terminalinfo[0] == 'f'))
	{
		printf("하차시 추가요금 : %d원\n", station0);
		return station0;
	}
	else if
		((c == 'b' && (currentinfo.terminalinfo[0] == 'c' || currentinfo.terminalinfo[0] == 'f'))
		|| (c == 'c' && (currentinfo.terminalinfo[0] == 'd' || currentinfo.terminalinfo[0] == 'b'))
		|| (c == 'd' && (currentinfo.terminalinfo[0] == 'e' || currentinfo.terminalinfo[0] == 'c'))
		|| (c == 'e' && (currentinfo.terminalinfo[0] == 'f' || currentinfo.terminalinfo[0] == 'd'))
		|| (c == 'f' && (currentinfo.terminalinfo[0] == 'b' || currentinfo.terminalinfo[0] == 'e')))

	{
		printf("하차시 추가요금 : %d원\n", station1);
		return station1;
	}
	else if
		((c == 'b' && (currentinfo.terminalinfo[0] == 'd' || currentinfo.terminalinfo[0] == 'e'))
		|| (c == 'c' && (currentinfo.terminalinfo[0] == 'e' || currentinfo.terminalinfo[0] == 'f'))
		|| (c == 'd' && (currentinfo.terminalinfo[0] == 'f' || currentinfo.terminalinfo[0] == 'b'))
		|| (c == 'e' && (currentinfo.terminalinfo[0] == 'b' || currentinfo.terminalinfo[0] == 'c'))
		|| (c == 'f' && (currentinfo.terminalinfo[0] == 'c' || currentinfo.terminalinfo[0] == 'd')))
	{
		printf("하차시 추가요금 : %d원\n", station2);
		return station2;
	}
}




