#include "subway_in.h"
#include "subway.h"
extern int money;
extern char c;
extern int terminalCount[6];
extern int check;
extern char username[20];
extern struct userInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}userinfo;
extern struct currentInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}currentinfo;

int check_in()			// 승차에서 어떤 요금을 부과할지 결정!  NULL안 먹히고... a~f가 아니여도 됨....
{
	//int time_a;			// userinfo.lastagtime;
	//int time_b;			// currentinfo.lastagtime;
	//int check_trans;	// 시간에 따른 환승 여부 판단
	//time_a = atoi(userinfo.lastTagTime);
	//time_b = atoi(currentinfo.lastTagTime);
	//check_trans = time_b - time_a;			//이건 0000으로 lasttagtime을 입력 받을때!!
	char* tempmin1;		// userinfo
	char* tempsec1;		// userinfo
	char* tempmin2;		// currentinfo
	char* tempsec2;		// currentinfo
	int check_trans;	// 시간에 따른 환승 여부 판단
	int totaltime1;
	int totaltime2;
	char temp1[10];			// 시간 잠시 저장하기 위한 문자열배열!
	char temp2[10];			// 시간 잠시 저장하기 위한 문자열배열!
	strcpy(temp1, currentinfo.lastTagTime);
	strcpy(temp2, userinfo.lastTagTime);
	tempmin1 = strtok(userinfo.lastTagTime, ":");
	tempsec1 = strtok(NULL, ":");
	totaltime1 = (atoi(tempmin1)) * 60 + atoi(tempsec1);
	tempmin2 = strtok(currentinfo.lastTagTime, ":");
	tempsec2 = strtok(NULL, ":");
	totaltime2 = (atoi(tempmin2)) * 60 + atoi(tempsec2);
	strcpy(currentinfo.lastTagTime, temp1);
	strcpy(userinfo.lastTagTime, temp2);

	check_trans = totaltime2 - totaltime1;
	check = 0;
	if (userinfo.in_out == BOARD && currentinfo.in_out == BOARD)
	{
		if ((userinfo.terminalinfo[0] == 'a' && userinfo.transportation == METRO && currentinfo.terminalinfo[0] != 'a' &&	currentinfo.transportation == METRO)
			|| (userinfo.terminalinfo[0] != 'a' && userinfo.transportation == BUS && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO))
		{
			currentinfo.balance = notcal_trans(); // 1750원 OR 1650원 (버스->지하철 환승이 1650원, 지하철->버스 환승이 1750원)
			check = 2;

		}

		else if (userinfo.terminalinfo[0] != 'a' && userinfo.transportation == METRO && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO)
		{
			currentinfo.balance = notcal_nottrans(); // 1250원
			check = 2;


		}
		else if (userinfo.terminalinfo[0] == 'a' && userinfo.transportation == BUS && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO)
		{
			currentinfo.balance = basic();	// 기본료 1050원 : 버스 승차 후 지하철 승차
			check = 2;

		}

	}
	if (userinfo.in_out == LEFT && currentinfo.in_out == BOARD)
	{
		if (userinfo.transportation == BUS && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO	&& check_trans <= 15)
		{
			c = currentinfo.terminalinfo[0]; // 환승일때 userinfo에서는 알파벳이 바뀌므로 전역변수 c에 저장해준다.
			currentinfo.balance = cal_trans();	// 환승 0원 : 버스하차 후 지하철 승차

		}
		else if ((userinfo.terminalinfo[0] != 'a' && userinfo.transportation == METRO && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO)
			|| (userinfo.terminalinfo[0] == 'a' && userinfo.transportation == METRO && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO)
			|| (userinfo.terminalinfo[0] == 'a' && userinfo.transportation == BUS && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO
			&& check_trans >15))
		{
			//basic();		// 기본료 1050원 : 지하철 하차 후 지하철 승차 , 최초탑승 포함, 환승 시간 지난 경우!
			currentinfo.balance = basic(); // 1050원
			check = 2;
		}

	}

}

int notcal_trans() {		// 미정산&환승(전에 탄게 버스)
	int extra_fee_a = 600;	// 버스->지하철 환승 후 미정산 추가요금
	int extra_fee_b = 700;	// 지하철->버스 환승 후 미정산 추가요금

	if (userinfo.terminalinfo[0] != 'a' && userinfo.transportation == BUS && currentinfo.terminalinfo[0] != 'a' && currentinfo.transportation == METRO)
	{
		printf("%d원\n", BASIC_FEE + extra_fee_a);
		return BASIC_FEE + extra_fee_a;
	}
	else if (userinfo.terminalinfo[0] == 'a' && userinfo.transportation == METRO && currentinfo.terminalinfo[0] != 'a' &&	currentinfo.transportation == METRO)
	{
		printf("%d원\n", BASIC_FEE + extra_fee_b);
		return BASIC_FEE + extra_fee_b;
	}




}
int notcal_nottrans() {		// 미정산&미환승(전에 탄게 지하철)   
	int extra_fee = 200;
	printf("%d원\n", BASIC_FEE + extra_fee);
	return BASIC_FEE + extra_fee;
}

int cal_trans() {			// 정산&환승(전에 탄게 버스)
	int zero = 0;
	printf("%d원\n", zero);
	return zero;


}
int basic() {				// 처음타거나 전에 탄게 버스인데 내릴때 안찍었을경우
	printf("%d원\n", BASIC_FEE);
	return BASIC_FEE;

}



