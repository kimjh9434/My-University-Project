#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <Windows.h>
#include <time.h>
#include <termios.h>
#include <unistd.h>


#define BASIC_FEE 1050
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1

static struct termios initial_settings, new_settings;

static int peek_character = -1;


char* getLastTagTime();
int getTransportation();
int getin_out();
int getBalance();
char* getTerminalinfo();
void tagInput();
void saveInfo();
void initialize();
int kbhit();
int readch();


