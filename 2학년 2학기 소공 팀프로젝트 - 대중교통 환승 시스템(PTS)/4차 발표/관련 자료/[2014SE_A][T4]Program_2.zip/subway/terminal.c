#include "terminal.h"
#include "subway.h"
#include "subway_in.h"
#include "subway_out.h"
#include "kbhit.h"

extern int money;
extern char c;
extern int terminalCount[6];
extern int check;
extern char username[20];
extern struct userInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}userinfo;

extern struct currentInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}currentinfo;


//유저정보는 한줄로 입력받아서 처리
char* getLastTagTime(){
	FILE *f;		/*유저 태그파일 한줄에 한번의 태그정보 모두 입력*/
	char userInput[MAX_USER_INPUT];
	char tagTime[20];
	int itemp = 2000;
	char ctemp[10];

	if (!strstr(username, ".txt")){
		strcat(username, ".txt");
	}
	f = fopen(username, "r+");
	if (f == NULL){
		printf("최초 충전 금액을 입력:");
		scanf("%d", &itemp);
		fflush(stdin);

		f = fopen(username, "w+");
		fputs("n n n ", f);
		sprintf(ctemp, "%d", itemp);

		fputs(ctemp, f);
		fputs(" n", f);
		fclose(f);
	}
	fopen(username, "r");
	while (fgets(userInput, MAX_USER_INPUT, f) != NULL){}
	fclose(f);

	/*userInput 형태 유저카드정보에 type들 한줄로 이어져 있음.*/
	/*tagTime[12] = '\0';
	strncpy(tagTime,userInput,12);*/
	strcpy(tagTime, strtok(userInput, " "));
	printf("lasttagtime : %s\n", tagTime);
	return tagTime;
}
// 태그된 시간 찾아서 반환해주는 함수

int getTransportation(){
	FILE *f;		//유저 태그파일 한줄에 한번의 태그정보 모두 입력
	char userInput[MAX_USER_INPUT];
	char temp[6];
	int itemp = 2000;
	char ctemp[10];
	
	if (!strstr(username, ".txt")){
		strcat(username, ".txt");
	}
	f = fopen(username, "r+");
	if (f == NULL){
		printf("최초 충전 금액을 입력:");
		scanf("%d", &itemp);
		fflush(stdin);

		f = fopen(username, "w+");
		fputs("n n n ", f);
		sprintf(ctemp, "%d", itemp);

		fputs(ctemp, f);
		fputs(" n", f);
		fclose(f);
	}
	fopen(username, "r");
	while (fgets(userInput, MAX_USER_INPUT, f) != NULL){}
	fclose(f);
	//파일처리구간

	strtok(userInput, " ");
	//태그된 시간	
	strcpy(temp, strtok(NULL, " "));
	//교통수단
	printf("transport : %s\n", temp);

	if (strcmp(temp, "BUS") == 0)
		return BUS;
	else if (strcmp(temp, "METRO") == 0)
		return METRO;
	else
		return METRO;
}
// 버스면 0반환, 지하철이면 1반환, 최초탑승이면 이전 탑승수단은 지하철로 정한다.
// 지하철터미널에선 지하철이고 하차인 경우 기본금액이기에

int getin_out() {
	FILE *f;		//유저 태그파일 한줄에 한번의 태그정보 모두 입력
	char userInput[MAX_USER_INPUT];
	char temp[4];
	int itemp = 2000;
	char ctemp[10];

	if (!strstr(username, ".txt")){
		strcat(username, ".txt");
	}
	f = fopen(username, "r+");
	if (f == NULL){
		printf("최초 충전 금액을 입력:");
		scanf("%d", &itemp);
		fflush(stdin);

		f = fopen(username, "w+");
		fputs("n n n ", f);
		sprintf(ctemp, "%d", itemp);

		fputs(ctemp, f);
		fputs(" n", f);
		fclose(f);
	}
	fopen(username, "r");
	while (fgets(userInput, MAX_USER_INPUT, f) != NULL){}
	fclose(f);
	//파일처리구간

	strtok(userInput, " ");
	//태그된 시간
	strtok(NULL, " ");
	//교통수단 지나고
	strcpy(temp, strtok(NULL, " "));

	printf("inout:%s\n", temp);

	if (strcmp(temp, "BOARD") == 0)
		return BOARD;
	else if (strcmp(temp, "LEFT") == 0)
		return LEFT;
	else
		return LEFT;
}
// 유저카드에 탑승정보가 승차면 0 하차면 1 최초면 하차이다.
// 버스터미널에선 이전에 버스에서 하차한 경우에 기본금액이기에.

int getBalance() {
	FILE *f;		//유저 태그파일 한줄에 한번의 태그정보 모두 입력
	char userInput[MAX_USER_INPUT];
	char* balance;
	int i = 0;
	int itemp = 2000;
	char ctemp[10];

	if (!strstr(username, ".txt")){
		strcat(username, ".txt");
	}
	f = fopen(username, "r+");
	if (f == NULL){
		printf("최초 충전 금액을 입력:");
		scanf("%d", &itemp);
		fflush(stdin);

		f = fopen(username, "w+");
		fputs("n n n ", f);
		sprintf(ctemp, "%d", itemp);

		fputs(ctemp, f);
		fputs(" n", f);
		fclose(f);
	}
	fopen(username, "r");
	while (fgets(userInput, MAX_USER_INPUT, f) != NULL){}
	fclose(f);
	//파일처리구간

	strtok(userInput, " ");
	//태그된 시간
	for (i = 0; i<2; i++)
		strtok(NULL, " ");
	//교통수단, 승차하차

	balance = strtok(NULL, " ");
	printf("balance: %s\n", balance);
	return atoi(balance);
}
//잔액 반환

char* getTerminalinfo(){

	FILE *f;		//유저 태그파일 한줄에 한번의 태그정보 모두 입력
	char userInput[MAX_USER_INPUT];
	char terminalinfo[6];
	int i = 0;
	int itemp = 2000;
	char ctemp[10];

	if (!strstr(username, ".txt")){
		strcat(username, ".txt");
	}
	f = fopen(username, "r+");
	if (f == NULL){
		printf("최초 충전 금액을 입력:");
		scanf("%d", &itemp);
		fflush(stdin);

		f = fopen(username, "w+");
		fputs("n n n ", f);
		sprintf(ctemp, "%d", itemp);

		fputs(ctemp, f);
		fputs(" n", f);
		fclose(f);
	}
	fopen(username, "r");
	while (fgets(userInput, MAX_USER_INPUT, f) != NULL){}
	fclose(f);
	//파일처리구간

	strtok(userInput, " ");
	//태그된 시간
	for (i = 0; i<3; i++)
		strtok(NULL, " ");
	//교통수단, 승차하차, 잔액

	strcpy(terminalinfo, strtok(NULL, " "));
	printf("terminal:%s\n", terminalinfo);
	return terminalinfo;
}
//탑승 단말기 정보 반환

void initialize(){
	FILE *f;
	int i;

	f = fopen("metro.txt", "w");
	fputs("", f);
	for (i = 0; i < 6; i++)
		terminalCount[i] = 0;
}



void tagInput(){
	time_t timer;			//현재시간 
	time_t initTimer;		//시스템 최초시작시간
	struct tm *t;
	char tempSecond[3];		// 초를 char 배열로
	char tempMinute[3];		// 분을 char 배열로
	char cterminalCount[3];	//단말기정보의 count 값을 char로 저장해줌
	char useMetro = 'z';	//지하철 이용하는지 확인
	char metrob[3] = "0_";			//지하철 사용
	int secTime = 0;			//시스템 시작으로부터 현재시간 초단위 차이
	int min;
	int sec;
	int tempi = 0;					//in out 버퍼
	int initializer = 1;				//초기화여부 확인
	int ios = 0;							//승차하차 입력버퍼
	int ch = 0;
	char select;
	initTimer = time(NULL);			//시간을 초단위로 받음
	t = localtime(&initTimer);		//시간의 시분초 분할

	while (1){

		printf("사용자 이름 입력:");
		printf("\n");
		while (1){
			tempi = 0;

			timer = time(NULL);		//시간을 초단위로 받음
			t = localtime(&timer);	//시간의 시분초 분할

			min = t->tm_min % 3;
			sec = t->tm_sec;
			sprintf(tempSecond, "%d", sec);	//태그시간에 분 입력
			sprintf(tempMinute, "%d", min);	//태그시간에 초 입력

			strcpy(currentinfo.lastTagTime, tempMinute);
			strcat(currentinfo.lastTagTime, ":");
			strcat(currentinfo.lastTagTime, tempSecond);

			printf("%02d:%02d\n", min, sec);

			/*3분이면*/
			if (min * 60 + sec == 179){
				//초기화
				Sleep(1500);
				initialize();
				initializer = 1;
				printf("\n초기화!\n");
				//terminalCount 초기화 필요할수도,
				initTimer = time(NULL);
			}

			if (kbhit()){
				scanf("%s", &username);
				fflush(stdin);
				printf("\nTAG TIME %02d:%02d\n", min, sec);
				break;
			}
			Sleep(1000);

			/*break;*/
		}
		//입력한다

		printf("==================\n");
		printf("USER INFORMATION\n");
		printf("==================\n");
		if (initializer == 1)
		{
			//탑승/하차와 지하철/버스 설정, 
			//최초입력이던 초기화 후 입력이던 상관없음
			userinfo.transportation = getTransportation();
			userinfo.in_out = getin_out();
			/*printf("처음 입력시 : %d\n", userinfo.in_out)*/;
			//초기화했을때, 인간이 안내린경우 미정산
			tempi = userinfo.in_out;
			if (tempi == BOARD)
			{
				strcpy(userinfo.lastTagTime, getLastTagTime());

				userinfo.balance = getBalance();
				strcpy(userinfo.terminalinfo, getTerminalinfo());
				tempi = 3;
				//태그시간, 잔액, 단말기정보 입력
				printf("초기화 전 하차못함\n");

			}

			//초기화했을 때 내린상태거나, 최초입력 시, 무조건 기본금액으로 가게
			//이떄는 userinfo가 교통수단 METRO, LEFT 이어야하고
			//lasttagtime, terminalinfo 는 상관이 없기에 현재시간, 널 입력
			else{
				userinfo.in_out = LEFT;            //
				userinfo.transportation = METRO;      //
				strcpy(userinfo.lastTagTime, currentinfo.lastTagTime);
				userinfo.balance = getBalance();
				strcpy(userinfo.terminalinfo, "");
				printf("초기화 후 최초탑승\n");
			}
			printf("초기화처리 후 inout %d\n", userinfo.in_out);
			initializer = 0;
		}

		//대부분의 경우
		else{
			strcpy(userinfo.lastTagTime, getLastTagTime());
			userinfo.transportation = getTransportation();
			userinfo.in_out = getin_out();
			userinfo.balance = getBalance();
			strcpy(userinfo.terminalinfo, getTerminalinfo());
		}

		//currentinfo 정보 설정
		do{
			printf("탑승(0) 하차(1) : ");
			scanf("%d", &ios);
			fflush(stdin);
			fflush(stdin);
			if (((userinfo.in_out == LEFT) && ios == LEFT) || (tempi == 3) && (ios == 1) || 
				(userinfo.in_out == BOARD && userinfo.transportation == BUS && (ios==1))){
				printf("최초거나 하차한뒤면 하차할순 없다 or 버스 승차후 지하철에서 하차할 수 없다. \n");
				tempi = 0;
			}
			else if (ios == 0){
				/*printf("BOARD\n");*/
				currentinfo.in_out = BOARD;
				break;
			}
			else if (ios == 1){
				/*printf("LEFT\n");*/
				currentinfo.in_out = LEFT;
				break;
			}
			else if (ios<0)
				printf("틀렸다\n");
		} while (1);
		//지금 탑승 하차 설정


		while (1){
			currentinfo.transportation = METRO;
			printf("건대(b), 강남(c), 신림(d), 합정(e), 동역사(f)");
			while (getchar() != '\n');
			scanf("%c", &metrob);


			if (metrob[0] == 'b'){
				printf("건대\n");
				strcpy(currentinfo.terminalinfo, metrob);

				check_in_out(&ios);
				break;
			}

			else if (metrob[0] == 'c'){
				printf("강남\n");
				strcpy(currentinfo.terminalinfo, metrob);

				check_in_out(&ios);
				break;
			}

			else if (metrob[0] == 'd'){
				printf("신림\n");
				strcpy(currentinfo.terminalinfo, metrob);

				check_in_out(&ios);
				break;
			}

			else if (metrob[0] == 'e'){
				printf("합정\n");
				strcpy(currentinfo.terminalinfo, metrob);

				check_in_out(&ios);
				break;
			}

			else if (metrob[0] == 'f'){
				printf("동역사\n");
				strcpy(currentinfo.terminalinfo, metrob);

				check_in_out(&ios);
				break;
			}

			
			else{}


		}
		//지하철의 경우, 어느역으로 가는가 결정





		//잔액테스트가 성공했을경우, 저장해준다


		while (1)
		{
			if (ios == 1)		//하차일때는 요금 부족 판단 안하므로!!
			{

				saveInfo();
				break;
			}

			else if (ios == 0)	// 승차일때는 요금 부족 확인하고!
			{
				balance_check();

				if ((userinfo.balance >= money))
				{
					if (check == 2)
					{
						if (metrob[0] == 'b')
						{
							terminalCount[1]++;
							sprintf(cterminalCount, "%d", terminalCount[1]);
							strcpy(currentinfo.terminalinfo, metrob);
							strcat(currentinfo.terminalinfo, cterminalCount);
						}
						else if (metrob[0] == 'c')
						{
							terminalCount[2]++;
							sprintf(cterminalCount, "%d", terminalCount[2]);
							strcpy(currentinfo.terminalinfo, metrob);
							strcat(currentinfo.terminalinfo, cterminalCount);
						}
						else if (metrob[0] == 'd')
						{
							terminalCount[3]++;
							sprintf(cterminalCount, "%d", terminalCount[3]);
							strcpy(currentinfo.terminalinfo, metrob);
							strcat(currentinfo.terminalinfo, cterminalCount);
						}
						else if (metrob[0] == 'e')
						{
							terminalCount[4]++;
							sprintf(cterminalCount, "%d", terminalCount[4]);
							strcpy(currentinfo.terminalinfo, metrob);
							strcat(currentinfo.terminalinfo, cterminalCount);
						}
						else if (metrob[0] == 'f')
						{
							terminalCount[5]++;
							sprintf(cterminalCount, "%d", terminalCount[5]);
							strcpy(currentinfo.terminalinfo, metrob);
							strcat(currentinfo.terminalinfo, cterminalCount);
						}
					}

					strcpy(userinfo.terminalinfo, currentinfo.terminalinfo);
					userinfo.balance = userinfo.balance - currentinfo.balance;


					saveInfo();

				}
				break;
			}
			else if ((userinfo.balance < money))
				break;
		}
		money = 0;
		/*printf("%d", userinfo.in_out);*/
	}

}


void saveInfo(){
	FILE *f;
	char cbalance[10];	//잔액 char 배열로 할당하기 위한 값


	f = fopen(username, "a");
	if (f == NULL)	{ perror("사용자파일이 없습니다"); }

	else{
		fputs("\n", f);
		//한줄뛰고

		fputs(currentinfo.lastTagTime, f);
		fputs(" ", f);
		//태그시간 입력


		if (currentinfo.transportation == 0)
			fputs("BUS", f);
		else if (currentinfo.transportation == 1)
			fputs("METRO", f);
		else
			printf("transportation ERROR\n");
		fputs(" ", f);
		//버스 혹은 지하철 파일에 입력

		if (currentinfo.in_out == 0)
			fputs("BOARD", f);
		else if (currentinfo.in_out == 1)
			fputs("LEFT", f);
		else
			printf("in_out ERROR\n");
		fputs(" ", f);
		//탑승 하차 파일에 입력

		/*realBalance = userinfo.balance - currentinfo.balance;*/
		sprintf(cbalance, "%d", userinfo.balance);
		// c배열에 잔액 입력 함수가 캐릭터 배열로 입력해야되거든
		fputs(cbalance, f);
		fputs(" ", f);
		//잔액 파일에 입력

		fputs(currentinfo.terminalinfo, f);
		//터미널정보 파일에 입력
		
	
	}
	/*fputs("\n", f);*/
	fclose(f);
	


	//터미널 파일에 저장
	f = fopen("metro.txt", "a + ");

	/*fputs("\n", f);*/
	//한줄뛰고

	fputs(currentinfo.lastTagTime, f);
	fputs(" ", f);
	//태그시간 입력


	if (currentinfo.transportation == 0)
		fputs("BUS", f);
	else if (currentinfo.transportation == 1)
		fputs("METRO", f);
	else
		printf("transportation ERROR\n");
	fputs(" ", f);
	//버스 혹은 지하철 파일에 입력

	if (currentinfo.in_out == 0)
		fputs("BOARD", f);
	else if (currentinfo.in_out == 1)
		fputs("LEFT", f);
	else
		printf("in_out ERROR\n");
	fputs(" ", f);
	//탑승 하차 파일에 입력


	sprintf(cbalance, "%d", currentinfo.balance);
	// c배열에 잔액 입력 함수가 캐릭터 배열로 입력해야되거든
	fputs(cbalance, f);
	fputs(" ", f);
	//잔액 파일에 입력

	fputs(currentinfo.terminalinfo, f);
	//터미널정보 파일에 입력
	
	fputs("\n", f);
	fclose(f);
	
}

