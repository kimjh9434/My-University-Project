#include "subway.h"
#include "subway_in.h"
#include "subway_out.h"

extern int money;
extern char c;
extern int terminalCount[6];
extern int check;
extern char username[20];
extern struct userInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}userinfo;
extern struct currentInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}currentinfo;

int balance_check()
{

	if (currentinfo.balance == BUS)		// 환승인 경우			
	{
		money = currentinfo.balance + 600;
		if (userinfo.balance < money)

			printf("요금이 부족해서 승차하실 수 없습니다!!!\n");


		else
		{
			money -= 600;
			/*userinfo.balance = userinfo.balance - currentinfo.balance;*/
			userinfo.in_out = currentinfo.in_out;
			strcpy(userinfo.lastTagTime, currentinfo.lastTagTime);
			strcpy(currentinfo.terminalinfo, userinfo.terminalinfo);
			userinfo.transportation = currentinfo.transportation;
			printf("승차 고고~~\n");

		}
	}
	else                            // 환승이 아닌 경우
	{
		money = currentinfo.balance + 200;
		if (userinfo.balance < money)

			printf("요금이 부족해서 승차하실 수 없습니다!!!\n");


		else
		{

			money -= 200;
			/*userinfo.balance = userinfo.balance - currentinfo.balance;*/

			userinfo.in_out = currentinfo.in_out;
			strcpy(userinfo.lastTagTime, currentinfo.lastTagTime);
			//strcpy(userinfo.terminalinfo, currentinfo.terminalinfo);
			userinfo.transportation = currentinfo.transportation;
			printf("승차 고고~~\n");

		}
	}
	return 0;
}

void check_in_out(int *a)
{
	if (*a == BOARD)
		check_in();
	else if (*a == LEFT)
		check_out();

}


