#include "subway_out.h"
#include "subway_in.h"
#include "terminal.h"

#define BASIC_FEE 1050
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1

int money;
char c;
int terminalCount[6];
int check;
char username[20];
struct userInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}userinfo;
struct currentInfo{
	char lastTagTime[20];
	int transportation;
	int in_out;
	int balance;
	char terminalinfo[6];
}currentinfo;

int main()
{
	tagInput();

	return 0;
}


