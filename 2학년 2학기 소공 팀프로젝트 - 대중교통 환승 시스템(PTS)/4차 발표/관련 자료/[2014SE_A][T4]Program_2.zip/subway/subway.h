#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

#define BASIC_FEE 1050
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1

int balance_check();
void check_in_out(int *a);


