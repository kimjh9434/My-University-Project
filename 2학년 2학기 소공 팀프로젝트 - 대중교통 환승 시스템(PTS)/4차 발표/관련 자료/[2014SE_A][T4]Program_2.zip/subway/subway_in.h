#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

#define BASIC_FEE 1050
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1



int notcal_trans();		// 미정산&환승(전에 탄게 버스)
int notcal_nottrans();		// 미정산&미환승(전에 탄게 지하철)
int cal_trans();			// 정산&환승(전에 탄게 버스)
int basic();				// 처음타거나 전에 탄게 버스인데 내릴때 안찍었을경우
int check_in();				// 승차에서 어떤 요금을 부과할지 결정!


