#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>



#define BASIC_FEE 1050
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1




int nottrans_cal();		// 미환승(전에 탄게 지하철)요금 계산
int trans_cal();			// 환승(전에 탄게 버스)요금 계산
int check_out();			// 하차에서 어떤 요금을 부과할지 결정!


