#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "busbus2.h"
#include "busInput2.h"
#define MAX_USER_INPUT 50
#define BUS 0
#define METRO 1
#define BOARD 0
#define LEFT 1
extern struct userInfo userinfo;

extern struct currentInfo currentinfo;
extern int terminalCount;

int busBoardControl() //버스 승차컨트롤
{
	int result = 10;
	char* tempmin1;
	char* tempsec1;
	char* tempmin2;
	char* tempsec2;
	int check_trans;   // 시간에 따른 환승 여부 판단
	int totaltime1;
	int totaltime2;
	char temp[10];         // 시간 잠시 저장하기 위한 문자열배열!
	char temp2[10];
	int cccc;

	strcpy(temp, currentinfo.lastTagTime);
	strcpy(temp2, userinfo.lastTagTime);
	tempmin1 = strtok(userinfo.lastTagTime, ":");
	tempsec1 = strtok(NULL, ":");
	totaltime1 = (atoi(tempmin1)) * 60 + atoi(tempsec1);
	tempmin2 = strtok(currentinfo.lastTagTime, ":");
	tempsec2 = strtok(NULL, ":");
	totaltime2 = (atoi(tempmin2)) * 60 + atoi(tempsec2);
	strcpy(currentinfo.lastTagTime, temp);
	strcpy(userinfo.lastTagTime, temp2);

	if (userinfo.in_out == LEFT && userinfo.transportation == METRO && 15>totaltime2-totaltime1) //지하철 찍고 하차후 버스 승차
	{
		result = 1;//최대 요금 500원 1번
		return result;
	}

	else if ((userinfo.transportation == BUS && userinfo.in_out == LEFT) || (userinfo.transportation == BUS && userinfo.terminalinfo[0] == 'a') || (userinfo.in_out == LEFT && userinfo.transportation == METRO && userinfo.terminalinfo[0] != 'a' && 15<totaltime2 - totaltime1))
	{
		result = 2;//기본요금 1050원 2번
		return result;
	}
	else if (userinfo.in_out == BOARD)
	{
		if (userinfo.terminalinfo[0] == 'a' && userinfo.transportation == METRO) //버스->지하철 하차시 노 태그
		{
			result = 3;//최대 요금 1650원 3번
			return result;
		}

		else if (userinfo.terminalinfo[0] != 'a' && userinfo.transportation == BUS) // 지하철->버스 하차시 노 태그
		{
			result = 4;//최대 요금 1750원 4번
			return result;
		}

		else if (userinfo.terminalinfo[0] != 'a' && userinfo.transportation == METRO) //지하철 하차시 노 태그
		{
			result = 5;//최대 요금 1250원 5번
			return result;
		}
	}
	else{
		return result;
	}
}

int busChargeShortageControl(int result) //승차시에 요금부족 컨트롤
{
	char cterminalCount[4];
	int charge = 3;

	switch (result)
	{
	case 1:
		if (userinfo.balance<500)
		{
			charge = 0;
		}
		else//충분할 시에 계산
		{
			charge = 1;
			currentinfo.balance = 0;
			strcpy(currentinfo.terminalinfo, userinfo.terminalinfo);
		}
		return charge;
		break;
	case 2:
		if (userinfo.balance<1050)
		{
			charge = 0;
		}
		else//충분할 시에 계산
		{
			charge = 1;
			currentinfo.balance = 1050;
			terminalCount++;
			sprintf(cterminalCount, "%d", terminalCount);
			strcpy(currentinfo.terminalinfo, "a_");
			strcat(currentinfo.terminalinfo, cterminalCount);
		}
		return charge;
		break;
	case 3:
		if (userinfo.balance<1650)
		{
			charge = 0;
		}
		else//충분할 시에 계산
		{
			charge = 1;
			currentinfo.balance = 1650;
			terminalCount++;
			sprintf(cterminalCount, "%d", terminalCount);
			strcpy(currentinfo.terminalinfo, "a_");
			strcat(currentinfo.terminalinfo, cterminalCount);
		}
		return charge;
		break;
	case 4:
		if (userinfo.balance<1750)
		{
			charge = 0;
		}
		else//충분할 시에 계산
		{
			charge = 1;
			currentinfo.balance = 1750;
			terminalCount++;
			sprintf(cterminalCount, "%d", terminalCount);
			strcpy(currentinfo.terminalinfo, "a_");
			strcat(currentinfo.terminalinfo, cterminalCount);
		}
		return charge;
		break;
	case 5:
		if (userinfo.balance<1250)
		{
			charge = 0;
		}
		else//충분할 시에 계산
		{
			charge = 1;
			currentinfo.balance = 1250;
			terminalCount++;
			sprintf(cterminalCount, "%d", terminalCount);
			strcpy(currentinfo.terminalinfo, "a_");
			strcat(currentinfo.terminalinfo, cterminalCount);

		}
		return charge;
		break;
	default:
		printf("머여이건\n");
		break;
	}
}

void busLeftControl() //버스 하차컨트롤
{
	int result = 10;
	char* tempmin1;
	char* tempsec1;
	char* tempmin2;
	char* tempsec2;
	int check_trans;   // 시간에 따른 환승 여부 판단
	int totaltime1;
	int totaltime2;
	char temp[10];         // 시간 잠시 저장하기 위한 문자열배열!
	char temp2[10];

	strcpy(temp, currentinfo.lastTagTime);
	strcpy(temp2, userinfo.lastTagTime);
	tempmin1 = strtok(userinfo.lastTagTime, ":");
	tempsec1 = strtok(NULL, ":");
	totaltime1 = (atoi(tempmin1)) * 60 + atoi(tempsec1);
	tempmin2 = strtok(currentinfo.lastTagTime, ":");
	tempsec2 = strtok(NULL, ":");
	totaltime2 = (atoi(tempmin2)) * 60 + atoi(tempsec2);
	strcpy(currentinfo.lastTagTime, temp);
	strcpy(userinfo.lastTagTime, temp2);

	//첫번째는 진짜 처음 탑승일때는 무조건 몇초건 0원
	//두번째는 환승 2번했을때 

	if (userinfo.in_out == BOARD && userinfo.transportation == BUS && currentinfo.balance == 0)
	{
		if (30 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 0;
		}

		else if (60 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 100;
		}

		else if (90 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 200;
		}

		else if (120 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 300;
		}

		else if (150 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 400;
		}

		else if (180 > totaltime2 - totaltime1)
		{
			currentinfo.balance = 500;
		}
	}
	else
		currentinfo.balance = 0;
}

int busin_outControl() //버스 승하차 컨트롤
{
	if (currentinfo.in_out == BOARD)
	{
		return busChargeShortageControl(busBoardControl());
	}
	else{
		busLeftControl();
		strcpy(currentinfo.terminalinfo, userinfo.terminalinfo);
		return 1;
	}
}


